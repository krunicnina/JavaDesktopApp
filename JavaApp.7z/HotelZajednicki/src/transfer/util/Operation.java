/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transfer.util;

/**
 *
 * @author En Kej
 */
public interface Operation {

    public static final int LOGIN = 0;

    public static final int GET_ALL_RECEPCIONER = 1;

    public static final int ADD_GOST = 2;
    public static final int UPDATE_GOST = 3;
    public static final int DELETE_GOST = 13;
    public static final int GET_ALL_GOST = 4;

    public static final int ADD_REZERVACIJA = 5;
    public static final int DELETE_REZERVACIJA = 6;
    public static final int UPDATE_REZERVACIJA = 7;
    public static final int GET_ALL_REZERVACIJA = 8;

    public static final int GET_ALL_STAVKA_REZERVACIJE = 9;

    public static final int GET_ALL_USLUGA = 10;

    public static final int GET_ALL_TIP_SOBE = 11;

    public static final int GET_ALL_SOBA = 12;

}
