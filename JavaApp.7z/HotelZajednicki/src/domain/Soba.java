/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author En Kej
 */
public class Soba extends AbstractDomainObject {

    private Long sobaID;
    private String brojSobe;
    private double cenaPoDanu;
    private String opisSobe;
    private TipSobe tipSobe;

    @Override
    public String toString() {
        return brojSobe + " (Tip sobe: " + tipSobe.getNazivTipaSobe() + ", Cena po danu: "
                + cenaPoDanu + "€)";
    }

    public Soba(Long sobaID, String brojSobe, double cenaPoDanu, String opisSobe, TipSobe tipSobe) {
        this.sobaID = sobaID;
        this.brojSobe = brojSobe;
        this.cenaPoDanu = cenaPoDanu;
        this.opisSobe = opisSobe;
        this.tipSobe = tipSobe;
    }

    public Soba() {
    }

    @Override
    public String nazivTabele() {
        return " Soba ";
    }

    @Override
    public String alijas() {
        return " s ";
    }

    @Override
    public String join() {
        return " JOIN TIPSOBE TS ON (TS.TIPSOBEID = S.TIPSOBEID) ";
    }

    @Override
    public ArrayList<AbstractDomainObject> vratiListu(ResultSet rs) throws SQLException {
        ArrayList<AbstractDomainObject> lista = new ArrayList<>();

        while (rs.next()) {
            
            TipSobe ts = new TipSobe(rs.getLong("TipSobeID"),
                    rs.getString("nazivTipaSobe"));
            
            Soba s = new Soba(rs.getLong("sobaID"), rs.getString("brojSobe"), 
                    rs.getDouble("cenaPoDanu"), rs.getString("brojSobe"), ts);

            lista.add(s);
        }

        rs.close();
        return lista;
    }

    @Override
    public String koloneZaInsert() {
        return "";
    }

    @Override
    public String vrednostZaPrimarniKljuc() {
        return " sobaID = " + sobaID;
    }

    @Override
    public String vrednostiZaInsert() {
        return "";
    }

    @Override
    public String vrednostiZaUpdate() {
        return "";
    }

    @Override
    public String uslov() {
        return "";
    }

    public Long getSobaID() {
        return sobaID;
    }

    public void setSobaID(Long sobaID) {
        this.sobaID = sobaID;
    }

    public String getBrojSobe() {
        return brojSobe;
    }

    public void setBrojSobe(String brojSobe) {
        this.brojSobe = brojSobe;
    }

    public double getCenaPoDanu() {
        return cenaPoDanu;
    }

    public void setCenaPoDanu(double cenaPoDanu) {
        this.cenaPoDanu = cenaPoDanu;
    }

    public String getOpisSobe() {
        return opisSobe;
    }

    public void setOpisSobe(String opisSobe) {
        this.opisSobe = opisSobe;
    }

    public TipSobe getTipSobe() {
        return tipSobe;
    }

    public void setTipSobe(TipSobe tipSobe) {
        this.tipSobe = tipSobe;
    }

}
