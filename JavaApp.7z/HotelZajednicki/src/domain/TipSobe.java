/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author En Kej
 */
public class TipSobe extends AbstractDomainObject {
    
    private Long tipSobeID;
    private String nazivTipaSobe;

    @Override
    public String toString() {
        return nazivTipaSobe;
    }

    public TipSobe(Long tipSobeID, String nazivTipaSobe) {
        this.tipSobeID = tipSobeID;
        this.nazivTipaSobe = nazivTipaSobe;
    }

    public TipSobe() {
    }
    
    @Override
    public String nazivTabele() {
        return " TipSobe ";
    }

    @Override
    public String alijas() {
        return " ts ";
    }

    @Override
    public String join() {
        return "";
    }

    @Override
    public ArrayList<AbstractDomainObject> vratiListu(ResultSet rs) throws SQLException {
        ArrayList<AbstractDomainObject> lista = new ArrayList<>();

        while (rs.next()) {
            TipSobe ts = new TipSobe(rs.getLong("TipSobeID"),
                    rs.getString("nazivTipaSobe"));

            lista.add(ts);
        }

        rs.close();
        return lista;
    }

    @Override
    public String koloneZaInsert() {
        return "";
    }

    @Override
    public String vrednostZaPrimarniKljuc() {
        return " TipSobeID = " + tipSobeID;
    }

    @Override
    public String vrednostiZaInsert() {
        return "";
    }

    @Override
    public String vrednostiZaUpdate() {
        return "";
    }

    @Override
    public String uslov() {
        return "";
    }

    public Long getTipSobeID() {
        return tipSobeID;
    }

    public void setTipSobeID(Long tipSobeID) {
        this.tipSobeID = tipSobeID;
    }

    public String getNazivTipaSobe() {
        return nazivTipaSobe;
    }

    public void setNazivTipaSobe(String nazivTipaSobe) {
        this.nazivTipaSobe = nazivTipaSobe;
    }
    
}
