/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author En Kej
 */
public class StavkaRezervacije extends AbstractDomainObject {

    private Rezervacija rezervacija;
    private int rbStavke;
    private double cenaStavke;
    private Usluga usluga;

    public StavkaRezervacije(Rezervacija rezervacija, int rbStavke, double cenaStavke, Usluga usluga) {
        this.rezervacija = rezervacija;
        this.rbStavke = rbStavke;
        this.cenaStavke = cenaStavke;
        this.usluga = usluga;
    }

    public StavkaRezervacije() {
    }

    @Override
    public String nazivTabele() {
        return " StavkaRezervacije ";
    }

    @Override
    public String alijas() {
        return " sr ";
    }

    @Override
    public String join() {
        return " JOIN USLUGA U USING (USLUGAID) "
                + "JOIN REZERVACIJA REZ USING (REZERVACIJAID) "
                + "JOIN SOBA S ON (S.SOBAID = REZ.SOBAID) "
                + "JOIN TIPSOBE TS ON (TS.TIPSOBEID = S.TIPSOBEID) "
                + "JOIN GOST G ON (G.GOSTID = REZ.GOSTID) "
                + "JOIN RECEPCIONER R ON (R.RECEPCIONERID = REZ.RECEPCIONERID) ";
    }

    @Override
    public ArrayList<AbstractDomainObject> vratiListu(ResultSet rs) throws SQLException {
        ArrayList<AbstractDomainObject> lista = new ArrayList<>();

        while (rs.next()) {
            Recepcioner r = new Recepcioner(rs.getLong("RecepcionerID"),
                    rs.getString("Ime"), rs.getString("Prezime"),
                    rs.getString("Username"), rs.getString("Password"));

            TipSobe ts = new TipSobe(rs.getLong("TipSobeID"),
                    rs.getString("nazivTipaSobe"));

            Soba s = new Soba(rs.getLong("sobaID"), rs.getString("brojSobe"),
                    rs.getDouble("cenaPoDanu"), rs.getString("brojSobe"), ts);

            Gost g = new Gost(rs.getLong("GostID"),
                    rs.getString("imeGosta"), rs.getString("prezimeGosta"),
                    rs.getString("email"), rs.getString("telefon"));

            Rezervacija rez = new Rezervacija(rs.getLong("rezervacijaID"),
                    rs.getDate("datumPocetka"), rs.getDate("datumKraja"),
                    rs.getInt("brojDana"), rs.getDouble("ukupnaCena"), s, g, r, null);

            Usluga u = new Usluga(rs.getLong("UslugaID"),
                    rs.getString("nazivUsluge"), rs.getString("opis"),
                    rs.getDouble("cenaUslugePoDanu"));

            StavkaRezervacije sr = new StavkaRezervacije(rez, rs.getInt("rbStavke"),
                    rs.getDouble("cenaStavke"), u);

            lista.add(sr);
        }

        rs.close();
        return lista;
    }

    @Override
    public String koloneZaInsert() {
        return " (rezervacijaID, rbStavke, cenaStavke, UslugaID) ";
    }

    @Override
    public String vrednostZaPrimarniKljuc() {
        return " rezervacijaID = " + rezervacija.getRezervacijaID();
    }

    @Override
    public String vrednostiZaInsert() {
        return " " + rezervacija.getRezervacijaID() + " ,  " + rbStavke + " , "
                + " " + cenaStavke + " ,  " + usluga.getUslugaID() + " ";
    }

    @Override
    public String vrednostiZaUpdate() {
        return "";
    }

    @Override
    public String uslov() {
        return " WHERE REZ.REZERVACIJAID = " + rezervacija.getRezervacijaID();
    }

    public Rezervacija getRezervacija() {
        return rezervacija;
    }

    public void setRezervacija(Rezervacija rezervacija) {
        this.rezervacija = rezervacija;
    }

    public int getRbStavke() {
        return rbStavke;
    }

    public void setRbStavke(int rbStavke) {
        this.rbStavke = rbStavke;
    }

    public double getCenaStavke() {
        return cenaStavke;
    }

    public void setCenaStavke(double cenaStavke) {
        this.cenaStavke = cenaStavke;
    }

    public Usluga getUsluga() {
        return usluga;
    }

    public void setUsluga(Usluga usluga) {
        this.usluga = usluga;
    }

}
