/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author En Kej
 */
public class Rezervacija extends AbstractDomainObject {

    private Long rezervacijaID;
    private Date datumPocetka;
    private Date datumKraja;
    private int brojDana;
    private double ukupnaCena;
    private Soba soba;
    private Gost gost;
    private Recepcioner recepcioner;
    private ArrayList<StavkaRezervacije> stavkeRezervacije;

    public Rezervacija(Long rezervacijaID, Date datumPocetka, Date datumKraja, int brojDana, double ukupnaCena, Soba soba, Gost gost, Recepcioner recepcioner, ArrayList<StavkaRezervacije> stavkeRezervacije) {
        this.rezervacijaID = rezervacijaID;
        this.datumPocetka = datumPocetka;
        this.datumKraja = datumKraja;
        this.brojDana = brojDana;
        this.ukupnaCena = ukupnaCena;
        this.soba = soba;
        this.gost = gost;
        this.recepcioner = recepcioner;
        this.stavkeRezervacije = stavkeRezervacije;
    }

    public Rezervacija() {
    }

    @Override
    public String nazivTabele() {
        return " Rezervacija ";
    }

    @Override
    public String alijas() {
        return " rez ";
    }

    @Override
    public String join() {
        return " JOIN SOBA S ON (S.SOBAID = REZ.SOBAID) "
                + "JOIN TIPSOBE TS ON (TS.TIPSOBEID = S.TIPSOBEID) "
                + "JOIN GOST G ON (G.GOSTID = REZ.GOSTID) "
                + "JOIN RECEPCIONER R ON (R.RECEPCIONERID = REZ.RECEPCIONERID) ";
    }

    @Override
    public ArrayList<AbstractDomainObject> vratiListu(ResultSet rs) throws SQLException {
        ArrayList<AbstractDomainObject> lista = new ArrayList<>();

        while (rs.next()) {
            Recepcioner r = new Recepcioner(rs.getLong("RecepcionerID"),
                    rs.getString("Ime"), rs.getString("Prezime"),
                    rs.getString("Username"), rs.getString("Password"));

            TipSobe ts = new TipSobe(rs.getLong("TipSobeID"),
                    rs.getString("nazivTipaSobe"));

            Soba s = new Soba(rs.getLong("sobaID"), rs.getString("brojSobe"),
                    rs.getDouble("cenaPoDanu"), rs.getString("brojSobe"), ts);

            Gost g = new Gost(rs.getLong("GostID"),
                    rs.getString("imeGosta"), rs.getString("prezimeGosta"),
                    rs.getString("email"), rs.getString("telefon"));

            Rezervacija rez = new Rezervacija(rs.getLong("rezervacijaID"),
                    rs.getDate("datumPocetka"), rs.getDate("datumKraja"),
                    rs.getInt("brojDana"), rs.getDouble("ukupnaCena"), s, g, r, null);

            lista.add(rez);
        }

        rs.close();
        return lista;
    }

    @Override
    public String koloneZaInsert() {
        return " (datumPocetka, datumKraja, brojDana, ukupnaCena, sobaID, gostID, "
                + "recepcionerID) ";
    }

    @Override
    public String vrednostZaPrimarniKljuc() {
        return " rezervacijaID = " + rezervacijaID;
    }

    @Override
    public String vrednostiZaInsert() {
        return "'" + new java.sql.Date(datumPocetka.getTime()) + "', "
                + "'" + new java.sql.Date(datumKraja.getTime()) + "', "
                + " " + brojDana + " ,  " + ukupnaCena + ", " + soba.getSobaID()
                + ", " + gost.getGostID() + ", " + recepcioner.getRecepcionerID();
    }

    @Override
    public String vrednostiZaUpdate() {
        return " datumPocetka = '" + new java.sql.Date(datumPocetka.getTime()) + "', "
                + "datumKraja = '" + new java.sql.Date(datumKraja.getTime()) + "', "
                + "brojDana = " + brojDana + ", ukupnaCena = " + ukupnaCena + " ";
    }

    @Override
    public String uslov() {
        return "";
    }

    public Long getRezervacijaID() {
        return rezervacijaID;
    }

    public void setRezervacijaID(Long rezervacijaID) {
        this.rezervacijaID = rezervacijaID;
    }

    public Date getDatumPocetka() {
        return datumPocetka;
    }

    public void setDatumPocetka(Date datumPocetka) {
        this.datumPocetka = datumPocetka;
    }

    public Date getDatumKraja() {
        return datumKraja;
    }

    public void setDatumKraja(Date datumKraja) {
        this.datumKraja = datumKraja;
    }

    public int getBrojDana() {
        return brojDana;
    }

    public void setBrojDana(int brojDana) {
        this.brojDana = brojDana;
    }

    public double getUkupnaCena() {
        return ukupnaCena;
    }

    public void setUkupnaCena(double ukupnaCena) {
        this.ukupnaCena = ukupnaCena;
    }

    public Soba getSoba() {
        return soba;
    }

    public void setSoba(Soba soba) {
        this.soba = soba;
    }

    public Gost getGost() {
        return gost;
    }

    public void setGost(Gost gost) {
        this.gost = gost;
    }

    public Recepcioner getRecepcioner() {
        return recepcioner;
    }

    public void setRecepcioner(Recepcioner recepcioner) {
        this.recepcioner = recepcioner;
    }

    public ArrayList<StavkaRezervacije> getStavkeRezervacije() {
        return stavkeRezervacije;
    }

    public void setStavkeRezervacije(ArrayList<StavkaRezervacije> stavkeRezervacije) {
        this.stavkeRezervacije = stavkeRezervacije;
    }

}
