/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author En Kej
 */
public class Gost extends AbstractDomainObject {
    
    private Long gostID;
    private String imeGosta;
    private String prezimeGosta;
    private String email;
    private String telefon;

    @Override
    public String toString() {
        return imeGosta + " " + prezimeGosta;
    }

    public Gost(Long gostID, String imeGosta, String prezimeGosta, String email, String telefon) {
        this.gostID = gostID;
        this.imeGosta = imeGosta;
        this.prezimeGosta = prezimeGosta;
        this.email = email;
        this.telefon = telefon;
    }

    public Gost() {
    }
    
    @Override
    public String nazivTabele() {
        return " Gost ";
    }

    @Override
    public String alijas() {
        return " g ";
    }

    @Override
    public String join() {
        return "";
    }

    @Override
    public ArrayList<AbstractDomainObject> vratiListu(ResultSet rs) throws SQLException {
        ArrayList<AbstractDomainObject> lista = new ArrayList<>();

        while (rs.next()) {
            Gost g = new Gost(rs.getLong("GostID"),
                    rs.getString("imeGosta"), rs.getString("prezimeGosta"),
                    rs.getString("email"), rs.getString("telefon"));

            lista.add(g);
        }

        rs.close();
        return lista;
    }

    @Override
    public String koloneZaInsert() {
        return " (imeGosta, prezimeGosta, email, telefon) ";
    }

    @Override
    public String vrednostZaPrimarniKljuc() {
        return " GostID = " + gostID;
    }

    @Override
    public String vrednostiZaInsert() {
        return "'" + imeGosta + "', '" + prezimeGosta + "', "
                + "'" + email + "', '" + telefon + "'";
    }

    @Override
    public String vrednostiZaUpdate() {
        return " email = '" + email + "', telefon = '" + telefon + "' ";
    }

    @Override
    public String uslov() {
        return "";
    }

    public Long getGostID() {
        return gostID;
    }

    public void setGostID(Long gostID) {
        this.gostID = gostID;
    }

    public String getImeGosta() {
        return imeGosta;
    }

    public void setImeGosta(String imeGosta) {
        this.imeGosta = imeGosta;
    }

    public String getPrezimeGosta() {
        return prezimeGosta;
    }

    public void setPrezimeGosta(String prezimeGosta) {
        this.prezimeGosta = prezimeGosta;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }
    
}
