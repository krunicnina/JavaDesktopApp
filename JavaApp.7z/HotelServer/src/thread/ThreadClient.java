/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thread;

import controller.ServerController;
import domain.Gost;
import domain.Recepcioner;
import domain.Rezervacija;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import transfer.Request;
import transfer.Response;
import transfer.util.ResponseStatus;
import transfer.util.Operation;

/**
 *
 * @author En Kej
 */
public class ThreadClient extends Thread {

    private Socket socket;

    ThreadClient(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            while (!socket.isClosed()) {
                ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                Request request = (Request) in.readObject();
                Response response = handleRequest(request);
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                out.writeObject(response);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Response handleRequest(Request request) {
        Response response = new Response(null, null, ResponseStatus.Success);
        try {
            switch (request.getOperation()) {
                case Operation.ADD_GOST:
                    ServerController.getInstance().addGost((Gost) request.getData());
                    break;
                case Operation.ADD_REZERVACIJA:
                    ServerController.getInstance().addRezervacija((Rezervacija) request.getData());
                    break;
                case Operation.DELETE_GOST:
                    ServerController.getInstance().deleteGost((Gost) request.getData());
                    break;
                case Operation.DELETE_REZERVACIJA:
                    ServerController.getInstance().deleteRezervacija((Rezervacija) request.getData());
                    break;
                case Operation.UPDATE_GOST:
                    ServerController.getInstance().updateGost((Gost) request.getData());
                    break;
                case Operation.UPDATE_REZERVACIJA:
                    ServerController.getInstance().updateRezervacija((Rezervacija) request.getData());
                    break;
                case Operation.GET_ALL_GOST:
                    response.setData(ServerController.getInstance().getAllGost());
                    break;
                case Operation.GET_ALL_RECEPCIONER:
                    response.setData(ServerController.getInstance().getAllRecepcioner());
                    break;
                case Operation.GET_ALL_REZERVACIJA:
                    response.setData(ServerController.getInstance().getAllRezervacija());
                    break;
                case Operation.GET_ALL_SOBA:
                    response.setData(ServerController.getInstance().getAllSoba());
                    break;
                case Operation.GET_ALL_TIP_SOBE:
                    response.setData(ServerController.getInstance().getAllTipSobe());
                    break;
                case Operation.GET_ALL_USLUGA:
                    response.setData(ServerController.getInstance().getAllUsluga());
                    break;
                case Operation.GET_ALL_STAVKA_REZERVACIJE:
                    response.setData(ServerController.getInstance().getAllStavkaRezervacije((Rezervacija) request.getData()));
                    break;
                case Operation.LOGIN:
                    Recepcioner recepcioner = (Recepcioner) request.getData();
                    Recepcioner ulogovani = ServerController.getInstance().login(recepcioner);
                    response.setData(ulogovani);
                    break;
                default:
                    return null;
            }
        } catch (Exception e) {
            response.setResponseStatus(ResponseStatus.Error);
            response.setException(e);
        }
        return response;
    }

}
