/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import domain.Gost;
import domain.Recepcioner;
import domain.Rezervacija;
import domain.Soba;
import domain.StavkaRezervacije;
import domain.TipSobe;
import domain.Usluga;
import java.util.ArrayList;
import so.recepcioner.SOGetAllRecepcioner;
import so.gost.SOAddGost;
import so.gost.SODeleteGost;
import so.gost.SOGetAllGost;
import so.gost.SOUpdateGost;
import so.login.SOLogin;
import so.rezervacija.SOAddRezervacija;
import so.rezervacija.SODeleteRezervacija;
import so.rezervacija.SOGetAllRezervacija;
import so.rezervacija.SOUpdateRezervacija;
import so.soba.SOGetAllSoba;
import so.stavkaRezervacije.SOGetAllStavkaRezervacije;
import so.tipSobe.SOGetAllTipSobe;
import so.usluga.SOGetAllUsluga;

/**
 *
 * @author En Kej
 */
public class ServerController {

    private static ServerController instance;

    private ServerController() {
    }

    public static ServerController getInstance() {
        if (instance == null) {
            instance = new ServerController();
        }
        return instance;
    }

    public Recepcioner login(Recepcioner recepcioner) throws Exception {
        SOLogin so = new SOLogin();
        so.templateExecute(recepcioner);
        return so.getUlogovani();
    }

    public void addGost(Gost gost) throws Exception {
        (new SOAddGost()).templateExecute(gost);
    }

    public void addRezervacija(Rezervacija rezervacija) throws Exception {
        (new SOAddRezervacija()).templateExecute(rezervacija);
    }

    public void deleteGost(Gost gost) throws Exception {
        (new SODeleteGost()).templateExecute(gost);
    }

    public void deleteRezervacija(Rezervacija rezervacija) throws Exception {
        (new SODeleteRezervacija()).templateExecute(rezervacija);
    }

    public void updateGost(Gost gost) throws Exception {
        (new SOUpdateGost()).templateExecute(gost);
    }

    public void updateRezervacija(Rezervacija rezervacija) throws Exception {
        (new SOUpdateRezervacija()).templateExecute(rezervacija);
    }

    public ArrayList<Recepcioner> getAllRecepcioner() throws Exception {
        SOGetAllRecepcioner so = new SOGetAllRecepcioner();
        so.templateExecute(new Recepcioner());
        return so.getLista();
    }

    public ArrayList<Gost> getAllGost() throws Exception {
        SOGetAllGost so = new SOGetAllGost();
        so.templateExecute(new Gost());
        return so.getLista();
    }

    public ArrayList<Rezervacija> getAllRezervacija() throws Exception {
        SOGetAllRezervacija so = new SOGetAllRezervacija();
        so.templateExecute(new Rezervacija());
        return so.getLista();
    }

    public ArrayList<StavkaRezervacije> getAllStavkaRezervacije(Rezervacija r) throws Exception {
        SOGetAllStavkaRezervacije so = new SOGetAllStavkaRezervacije();
        
        StavkaRezervacije sr = new StavkaRezervacije();
        sr.setRezervacija(r);
        
        so.templateExecute(sr);
        return so.getLista();
    }

    public ArrayList<Soba> getAllSoba() throws Exception {
        SOGetAllSoba so = new SOGetAllSoba();
        so.templateExecute(new Soba());
        return so.getLista();
    }

    public ArrayList<TipSobe> getAllTipSobe() throws Exception {
        SOGetAllTipSobe so = new SOGetAllTipSobe();
        so.templateExecute(new TipSobe());
        return so.getLista();
    }

    public ArrayList<Usluga> getAllUsluga() throws Exception {
        SOGetAllUsluga so = new SOGetAllUsluga();
        so.templateExecute(new Usluga());
        return so.getLista();
    }

}
