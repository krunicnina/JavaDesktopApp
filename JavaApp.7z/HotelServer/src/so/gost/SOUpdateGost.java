/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so.gost;

import db.DBBroker;
import domain.AbstractDomainObject;
import domain.Gost;
import java.util.ArrayList;
import so.AbstractSO;

/**
 *
 * @author En Kej
 */
public class SOUpdateGost extends AbstractSO {

    @Override
    protected void validate(AbstractDomainObject ado) throws Exception {
        if (!(ado instanceof Gost)) {
            throw new Exception("Prosledjeni objekat nije instanca klase Gost!");
        }

        Gost izmenjeniGost = (Gost) ado;

        ArrayList<Gost> gosti = (ArrayList<Gost>) (ArrayList<?>) DBBroker.getInstance().select(ado);

        for (Gost gost : gosti) {
            if (!gost.getGostID().equals(izmenjeniGost.getGostID())) {
                if (gost.getEmail().equals(izmenjeniGost.getEmail())) {
                    throw new Exception("Vec postoji gost sa tom email adresom!");
                }
                if (gost.getTelefon().equals(izmenjeniGost.getTelefon())) {
                    throw new Exception("Vec postoji gost sa tim brojem telefona!");
                }
            }
        }

    }

    @Override
    protected void execute(AbstractDomainObject ado) throws Exception {
        DBBroker.getInstance().update(ado);
    }

}
