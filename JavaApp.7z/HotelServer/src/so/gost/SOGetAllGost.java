/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so.gost;

import db.DBBroker;
import domain.AbstractDomainObject;
import domain.Gost;
import java.util.ArrayList;
import so.AbstractSO;

/**
 *
 * @author En Kej
 */
public class SOGetAllGost extends AbstractSO {

    private ArrayList<Gost> lista;

    @Override
    protected void validate(AbstractDomainObject ado) throws Exception {
        if (!(ado instanceof Gost)) {
            throw new Exception("Prosledjeni objekat nije instanca klase Gost!");
        }
    }

    @Override
    protected void execute(AbstractDomainObject ado) throws Exception {
        ArrayList<AbstractDomainObject> listaGostiju = DBBroker.getInstance().select(ado);
        lista = (ArrayList<Gost>) (ArrayList<?>) listaGostiju;
    }

    public ArrayList<Gost> getLista() {
        return lista;
    }

}
