/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so.tipSobe;

import db.DBBroker;
import domain.AbstractDomainObject;
import domain.TipSobe;
import java.util.ArrayList;
import so.AbstractSO;

/**
 *
 * @author En Kej
 */
public class SOGetAllTipSobe extends AbstractSO {

    private ArrayList<TipSobe> lista;

    @Override
    protected void validate(AbstractDomainObject ado) throws Exception {
        if (!(ado instanceof TipSobe)) {
            throw new Exception("Prosledjeni objekat nije instanca klase TipSobe!");
        }
    }

    @Override
    protected void execute(AbstractDomainObject ado) throws Exception {
        ArrayList<AbstractDomainObject> tipoviSoba = DBBroker.getInstance().select(ado);
        lista = (ArrayList<TipSobe>) (ArrayList<?>) tipoviSoba;
    }

    public ArrayList<TipSobe> getLista() {
        return lista;
    }

}
