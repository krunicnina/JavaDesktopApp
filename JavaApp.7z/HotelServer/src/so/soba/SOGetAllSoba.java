/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so.soba;

import db.DBBroker;
import domain.AbstractDomainObject;
import domain.Soba;
import java.util.ArrayList;
import so.AbstractSO;

/**
 *
 * @author En Kej
 */
public class SOGetAllSoba extends AbstractSO {

    private ArrayList<Soba> lista;

    @Override
    protected void validate(AbstractDomainObject ado) throws Exception {
        if (!(ado instanceof Soba)) {
            throw new Exception("Prosledjeni objekat nije instanca klase Soba!");
        }
    }

    @Override
    protected void execute(AbstractDomainObject ado) throws Exception {
        ArrayList<AbstractDomainObject> sobe = DBBroker.getInstance().select(ado);
        lista = (ArrayList<Soba>) (ArrayList<?>) sobe;
    }

    public ArrayList<Soba> getLista() {
        return lista;
    }

}
