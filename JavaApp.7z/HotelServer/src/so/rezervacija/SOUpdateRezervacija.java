/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so.rezervacija;

import db.DBBroker;
import domain.AbstractDomainObject;
import domain.Rezervacija;
import domain.StavkaRezervacije;
import so.AbstractSO;

/**
 *
 * @author En Kej
 */
public class SOUpdateRezervacija extends AbstractSO {

    @Override
    protected void validate(AbstractDomainObject ado) throws Exception {
        if (!(ado instanceof Rezervacija)) {
            throw new Exception("Prosledjeni objekat nije instanca klase Rezervacija!");
        }

        Rezervacija r = (Rezervacija) ado;

        if (r.getStavkeRezervacije().isEmpty()) {
            throw new Exception("Rezervacija mora da ima barem jednu stavku!");
        }

    }

    @Override
    protected void execute(AbstractDomainObject ado) throws Exception {
     
        DBBroker.getInstance().update(ado);

  
        Rezervacija r = (Rezervacija) ado;
      
        DBBroker.getInstance().delete(r.getStavkeRezervacije().get(0));

       
        for (StavkaRezervacije stavkaRezervacije : r.getStavkeRezervacije()) {
            DBBroker.getInstance().insert(stavkaRezervacije);
        }

    }

}
