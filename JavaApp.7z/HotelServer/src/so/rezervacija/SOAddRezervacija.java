/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so.rezervacija;

import db.DBBroker;
import domain.AbstractDomainObject;
import domain.Rezervacija;
import domain.StavkaRezervacije;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import so.AbstractSO;

/**
 *
 * @author En Kej
 */
public class SOAddRezervacija extends AbstractSO {

    @Override
    protected void validate(AbstractDomainObject ado) throws Exception {
        if (!(ado instanceof Rezervacija)) {
            throw new Exception("Prosledjeni objekat nije instanca klase Rezervacija!");
        }

        Rezervacija r = (Rezervacija) ado;

        if (r.getStavkeRezervacije().isEmpty()) {
            throw new Exception("Rezervacija mora da ima barem jednu stavku!");
        }

    }

    @Override
    protected void execute(AbstractDomainObject ado) throws Exception {

       
        PreparedStatement ps = DBBroker.getInstance().insert(ado);

        
        ResultSet tableKeys = ps.getGeneratedKeys();
        tableKeys.next();
        Long rezID = tableKeys.getLong(1);

     
        Rezervacija r = (Rezervacija) ado;
        r.setRezervacijaID(rezID);

       
        for (StavkaRezervacije stavkaRezervacije : r.getStavkeRezervacije()) {
            stavkaRezervacije.setRezervacija(r);
            DBBroker.getInstance().insert(stavkaRezervacije);
        }

    }

}
