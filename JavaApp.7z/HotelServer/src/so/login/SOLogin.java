/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so.login;

import db.DBBroker;
import domain.AbstractDomainObject;
import domain.Recepcioner;
import java.util.ArrayList;
import so.AbstractSO;

/**
 *
 * @author En Kej
 */
public class SOLogin extends AbstractSO {
    
    Recepcioner ulogovani;

    @Override
    protected void validate(AbstractDomainObject ado) throws Exception {
        if (!(ado instanceof Recepcioner)) {
            throw new Exception("Prosledjeni objekat nije instanca klase Recepcioner!");
        }
    }

    @Override
    protected void execute(AbstractDomainObject ado) throws Exception {

        Recepcioner r = (Recepcioner) ado;

        ArrayList<Recepcioner> recepcioneri
                = (ArrayList<Recepcioner>) (ArrayList<?>) DBBroker.getInstance().select(ado);

        for (Recepcioner recepcioner : recepcioneri) {
            if (recepcioner.getUsername().equals(r.getUsername())
                    && recepcioner.getPassword().equals(r.getPassword())) {
                ulogovani = recepcioner;
                return;
            }
        }

        throw new Exception("Ne postoji recepcioner sa tim kredencijalima.");
        
    }

    public Recepcioner getUlogovani() {
        return ulogovani;
    }
    
    

}
