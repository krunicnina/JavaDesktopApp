/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import domain.Gost;
import domain.Recepcioner;
import domain.Rezervacija;
import domain.Soba;
import domain.StavkaRezervacije;
import domain.TipSobe;
import domain.Usluga;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import session.Session;
import transfer.Request;
import transfer.Response;
import transfer.util.ResponseStatus;
import transfer.util.Operation;

/**
 *
 * @author En Kej
 */
public class ClientController {

    private static ClientController instance;

    private ClientController() {
    }

    public static ClientController getInstance() {
        if (instance == null) {
            instance = new ClientController();
        }
        return instance;
    }

    public Recepcioner login(Recepcioner recepcioner) throws Exception {
        return (Recepcioner) sendRequest(Operation.LOGIN, recepcioner);
    }

    public void addGost(Gost gost) throws Exception {
        sendRequest(Operation.ADD_GOST, gost);
    }

    public void addRezervacija(Rezervacija rezervacija) throws Exception {
        sendRequest(Operation.ADD_REZERVACIJA, rezervacija);
    }

    public void deleteGost(Gost gost) throws Exception {
        sendRequest(Operation.DELETE_GOST, gost);
    }

    public void deleteRezervacija(Rezervacija rezervacija) throws Exception {
        sendRequest(Operation.DELETE_REZERVACIJA, rezervacija);
    }

    public void updateGost(Gost gost) throws Exception {
        sendRequest(Operation.UPDATE_GOST, gost);
    }

    public void updateRezervacija(Rezervacija rezervacija) throws Exception {
        sendRequest(Operation.UPDATE_REZERVACIJA, rezervacija);
    }

    public ArrayList<Recepcioner> getAllRecepcioner() throws Exception {
        return (ArrayList<Recepcioner>) sendRequest(Operation.GET_ALL_RECEPCIONER, null);
    }

    public ArrayList<Gost> getAllGost() throws Exception {
        return (ArrayList<Gost>) sendRequest(Operation.GET_ALL_GOST, null);
    }

    public ArrayList<Rezervacija> getAllRezervacija() throws Exception {
        return (ArrayList<Rezervacija>) sendRequest(Operation.GET_ALL_REZERVACIJA, null);
    }

    public ArrayList<Soba> getAllSoba() throws Exception {
        return (ArrayList<Soba>) sendRequest(Operation.GET_ALL_SOBA, null);
    }

    public ArrayList<TipSobe> getAllTipSobe() throws Exception {
        return (ArrayList<TipSobe>) sendRequest(Operation.GET_ALL_TIP_SOBE, null);
    }

    public ArrayList<Usluga> getAllUsluga() throws Exception {
        return (ArrayList<Usluga>) sendRequest(Operation.GET_ALL_USLUGA, null);
    }

    public ArrayList<StavkaRezervacije> getAllStavkaRezervacije(Rezervacija r) throws Exception {
        return (ArrayList<StavkaRezervacije>) sendRequest(Operation.GET_ALL_STAVKA_REZERVACIJE, r);
    }

    private Object sendRequest(int operation, Object data) throws Exception {
        Request request = new Request(operation, data);

        ObjectOutputStream out = new ObjectOutputStream(Session.getInstance().getSocket().getOutputStream());
        out.writeObject(request);

        ObjectInputStream in = new ObjectInputStream(Session.getInstance().getSocket().getInputStream());
        Response response = (Response) in.readObject();

        if (response.getResponseStatus().equals(ResponseStatus.Error)) {
            throw response.getException();
        } else {
            return response.getData();
        }

    }
}
