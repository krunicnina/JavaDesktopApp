/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import controller.ClientController;
import domain.Rezervacija;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author En Kej
 */
public class TableModelRezervacije extends AbstractTableModel implements Runnable {

    private ArrayList<Rezervacija> lista;
    private String[] kolone = {"ID", "Gost", "Soba", "Datum pocetka", "Datum kraja",
        "Broj dana", "Ukupna cena"};
    private String parametar = "";

    public TableModelRezervacije() {
        try {
            lista = ClientController.getInstance().getAllRezervacija();
        } catch (Exception ex) {
            Logger.getLogger(TableModelRezervacije.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return kolone.length;
    }

    @Override
    public String getColumnName(int i) {
        return kolone[i];
    }

    @Override
    public Object getValueAt(int row, int column) {
        Rezervacija r = lista.get(row);
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");

        switch (column) {
            case 0:
                return r.getGost().getGostID();
            case 1:
                return r.getGost();
            case 2:
                return r.getSoba();
            case 3:
                return sdf.format(r.getDatumPocetka());
            case 4:
                return sdf.format(r.getDatumKraja());
            case 5:
                return r.getBrojDana();
            case 6:
                return r.getUkupnaCena() + "€";

            default:
                return null;
        }
    }

    public Rezervacija getSelectedRezervacija(int row) {
        return lista.get(row);
    }

    @Override
    public void run() {
        try {
            while (!Thread.currentThread().isInterrupted()) {
                Thread.sleep(10000);
                refreshTable();
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(TableModelRezervacije.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void setParametar(String parametar) {
        this.parametar = parametar;
        refreshTable();
    }

    public void refreshTable() {
        try {
            lista = ClientController.getInstance().getAllRezervacija();
            if (!parametar.equals("")) {
                ArrayList<Rezervacija> novaLista = new ArrayList<>();
                for (Rezervacija r : lista) {
                    if (r.getGost().getImeGosta().toLowerCase().contains(parametar.toLowerCase())
                            || r.getGost().getPrezimeGosta().toLowerCase().contains(parametar.toLowerCase())) {
                        novaLista.add(r);
                    }
                }
                lista = novaLista;
            }

            fireTableDataChanged();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
